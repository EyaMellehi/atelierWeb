<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="bienvenue.php" method="get">
        <input type="text" name="prenom" id="">
        <input type="number" name="rep" id="">
        <input type="submit" value="Cliquez ici" name="ok">
    </form>
</body>
</html>