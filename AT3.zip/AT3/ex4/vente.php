<?php

echo"Bienvenue dans la page d'achat immobiler";
?>