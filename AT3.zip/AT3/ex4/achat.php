<?php

echo"Bienvenue dans la page de vente immobiliere";
?>