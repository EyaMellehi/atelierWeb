<?php

echo"Bienvenue dans la page location immobiliere";
?>