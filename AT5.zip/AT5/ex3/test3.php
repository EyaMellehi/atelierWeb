<?php

include "const.php";
//include "salaire.php";
$o=new constrac("14d","eya","mellehi",3000,500,"14 novembre 2023","good");
$pp=new salarie("14d","eya","mellehi",3000,500);

echo $o->infosal();
?>