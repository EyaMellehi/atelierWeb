<?php
include "ex1.php";
$obj=new ville("rades","ben arous");
$obj1=new ville("chebba","mahdia");

echo $obj->get_info();
echo "<br>".$obj1;
 
?>